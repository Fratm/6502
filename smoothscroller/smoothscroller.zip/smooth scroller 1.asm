; COMMODORE 64 SMOOTH SCROLLING DEMO
; FORMATTED AND DOCUMENTED VERSION

* = $1000    ; START ADDRESS AT $1000 (4096)

; ============================================
; INITIALIZATION ROUTINE
; ============================================

          LDA  #$00 
          STA  $D020       ; SET BORDER COLOR TO BLACK (53280)
          STA  $D021       ; SET BACKGROUND COLOR TO BLACK (53281)
          LDA  #21
          STA  53272       ; SET CHARACTER SET MEMORY LOCATION

          LDA  #$93        ; CLEAR SCREEN CHARACTER
          JSR  $FFD2       ; CALL KERNAL ROUTINE TO OUTPUT CHARACTER
          
          LDA  #$00
          STA  OFFSET      ; INITIALIZE COLOR CYCLE OFFSET
         
          JSR  RESET       ; INITIALIZE SCROLL TEXT POINTER
          
          ; DISPLAY TITLE PAGE
          LDA  #< INTRO    ; LOW BYTE OF INTRO TEXT ADDRESS
          LDY  #> INTRO    ; HIGH BYTE OF INTRO TEXT ADDRESS
          JSR  $AB1E       ; KERNAL STRING PRINT ROUTINE (255 CHARS MAX)
          
          ; SETUP INTERRUPT SYSTEM
          SEI              ; DISABLE INTERRUPTS
          LDA  #$01        
          STA  $DC0D       ; DISABLE CIA #1 TIMER INTERRUPTS
          STA  $D01A       ; ENABLE VIC RASTER INTERRUPTS
          
          LDA  #< IRQ      ; LOW BYTE OF IRQ HANDLER
          STA  $0314       ; SET INTERRUPT VECTOR LOW BYTE
          LDA  #> IRQ      ; HIGH BYTE OF IRQ HANDLER
          STA  $0315       ; SET INTERRUPT VECTOR HIGH BYTE
          LDA  #$30        ; RASTER LINE $30 (48)
          STA  $D012       ; SET RASTER COMPARE REGISTER
         
          LDA  #$1B        ; %00011011
          STA  $D011       ; SET SCREEN CONTROL REGISTER
          CLI              ; ENABLE INTERRUPTS
          
O         JMP  O           ; INFINITE LOOP - MAIN PROGRAM WAITS HERE

; ============================================
; INTERRUPT HANDLER #1 - TOP OF SCREEN
; ============================================

IRQ
          LDA  #$01
          STA  $D019       ; ACKNOWLEDGE RASTER INTERRUPT

          LDA  #200        ; NORMAL HORIZONTAL SCROLL VALUE
          STA  53270       ; $D016 - HORIZONTAL SCROLL REGISTER
          
          LDA  #< IRQ2     ; CHAIN TO NEXT INTERRUPT HANDLER
          STA  $0314
          LDA  #> IRQ2
          STA  $0315
          
          LDA  #$83        ; RASTER LINE $83 (131)
          STA  $D012       ; SET NEXT RASTER INTERRUPT POSITION
          
          JMP  $EA81       ; JUMP TO KERNAL IRQ EXIT ROUTINE

; ============================================
; INTERRUPT HANDLER #2 - FIRST COLOR BAR
; ============================================
          
IRQ2
          LDA  #$01
          STA  $D019       ; ACKNOWLEDGE INTERRUPT
          
          LDX  #$00        ; INITIALIZE COLOR INDEX
LOOP      LDY  COLOURBAR1, X  ; LOAD COLOR VALUE FROM TABLE
          LDA  $D012       ; READ CURRENT RASTER LINE

WAIT      CMP  $D012       ; WAIT FOR RASTER LINE TO ADVANCE
          BEQ  WAIT        ; LOOP UNTIL RASTER MOVES
          
          STY  $D020       ; SET BORDER COLOR
          STY  $D021       ; SET BACKGROUND COLOR
          
          INX              ; INCREMENT COLOR INDEX
          CPX  #$05        ; CHECK IF ALL 5 COLORS DISPLAYED
          BNE  LOOP        ; CONTINUE IF NOT DONE
 
          LDA  PIX         ; GET CURRENT SCROLL POSITION
          STA  53270       ; $D016 - SET HORIZONTAL SCROLL
          
          LDA  #< IRQ3     ; CHAIN TO NEXT INTERRUPT HANDLER
          STA  $0314
          LDA  #> IRQ3
          STA  $0315
          LDA  #$B3        ; RASTER LINE $B3 (179)
          STA  $D012
          JMP  $EA81       ; EXIT TO KERNAL

; ============================================
; INTERRUPT HANDLER #3 - SECOND COLOR BAR
; ============================================

IRQ3
          LDA  #$01
          STA  $D019       ; ACKNOWLEDGE INTERRUPT
          
          LDX  #$00        ; INITIALIZE COLOR INDEX
LOOP2     LDY  COLOURBAR2, X  ; LOAD COLOR VALUE FROM TABLE
          LDA  $D012       ; READ CURRENT RASTER LINE

WAIT2     CMP  $D012       ; WAIT FOR RASTER LINE TO ADVANCE
          BEQ  WAIT2       ; LOOP UNTIL RASTER MOVES
          
          STY  $D020       ; SET BORDER COLOR
          STY  $D021       ; SET BACKGROUND COLOR
          
          INX              ; INCREMENT COLOR INDEX
          CPX  #$05        ; CHECK IF ALL 5 COLORS DISPLAYED
          BNE  LOOP2       ; CONTINUE IF NOT DONE
 
          LDA  #200        ; RESET TO NORMAL SCROLL VALUE
          STA  53270       ; $D016
          
          JSR  SCROLL      ; UPDATE SCROLL POSITION
          JSR  FADER       ; UPDATE COLOR CYCLING
          
          
          LDA  #< IRQ      ; CHAIN BACK TO FIRST INTERRUPT
          STA  $0314
          LDA  #> IRQ
          STA  $0315
          LDA  #$30        ; RASTER LINE $30 (48)
          STA  $D012
          JMP  $EA31       ; EXIT TO KERNAL

; ============================================
; SCROLL ROUTINE - SMOOTH HORIZONTAL SCROLL
; ============================================

SCROLL
          DEC  PIX         ; DECREASE PIXEL POSITION
          LDA  PIX
          CMP  #$BF        ; CHECK IF AT BOUNDARY
          BNE  EXIT        ; IF NOT, EXIT
          LDA  #$C7        ; RESET PIXEL POSITION
          STA  PIX
          
          ; SHIFT SCREEN CHARACTERS LEFT
          LDX  #$00
LOOP3     LDA  $0609, X    ; READ CHARACTER FROM POSITION+1
          STA  $0608, X    ; WRITE TO CURRENT POSITION
          INX
          CPX  #$27        ; 39 CHARACTERS (SCREEN WIDTH)
          BNE  LOOP3
          
          ; GET NEXT CHARACTER FROM SCROLL TEXT
          LDY  #$00  
          LDA  ($BB), Y    ; READ FROM TEXT POINTER
          CMP  #$00        ; CHECK FOR END OF TEXT
          BEQ  RESET       ; RESET IF AT END
          AND  #63         ; CONVERT TO SCREEN CODE
          STA  $0608 + 39  ; PLACE AT RIGHT EDGE OF SCREEN
          
          INC  $BB         ; INCREMENT TEXT POINTER LOW BYTE
          BNE  EXIT        ; IF NO CARRY, EXIT
          INC  $BC         ; INCREMENT TEXT POINTER HIGH BYTE
          
EXIT
          RTS

; ============================================
; RESET SCROLL TEXT POINTER
; ============================================

RESET
          LDA  #< SCROLLTEXT  ; LOW BYTE OF SCROLL TEXT
          STA  $BB            ; SET POINTER LOW BYTE
          LDA  #> SCROLLTEXT  ; HIGH BYTE OF SCROLL TEXT
          STA  $BC            ; SET POINTER HIGH BYTE
          RTS

; ============================================
; COLOR FADER ROUTINE
; ============================================
      
FADER
          INC  DELAY       ; INCREMENT DELAY COUNTER
          LDA  DELAY
          CMP  #6          ; CHECK IF DELAY REACHED
          BNE  +           ; IF NOT, EXIT
          LDA  #$00        ; RESET DELAY
          STA  DELAY

          LDX  OFFSET      ; GET CURRENT COLOR OFFSET
          LDA  COLOUR, X   ; LOAD COLOR FROM TABLE
          STA  FLASH       ; STORE IN FLASH COLOR
          INC  OFFSET      ; NEXT COLOR
          LDA  OFFSET
          CMP  #8          ; CHECK IF AT END OF COLOR TABLE
          BNE  +           ; IF NOT, EXIT
          LDA  #$00        ; RESET OFFSET
          STA  OFFSET
+         RTS

; ============================================
; DATA TABLES
; ============================================

COLOUR    !BYTE 6,14,3,1,3,14,6,0  ; COLOR CYCLE TABLE

COLOURBAR1
          !BYTE $09, $08, $07, $01  ; ORANGE, BROWN, YELLOW, WHITE
FLASH     !BYTE $00                ; DYNAMIC FLASH COLOR
          
OFFSET    !BYTE 0                  ; COLOR CYCLE OFFSET

COLOURBAR2
          !BYTE $01, $07, $08, $09, $00  ; WHITE, YELLOW, BROWN, ORANGE, BLACK
          
PIX       !BYTE $C7                ; CURRENT PIXEL SCROLL POSITION

DELAY     !BYTE 0                  ; FADER DELAY COUNTER

; ============================================
; TEXT DATA
; ============================================

INTRO
          !SCR "{WHITE}WELCOME TO MY NEW SMOOTH SCROLLER"
          !BYTE $0D,$0D    ; CARRIAGE RETURNS
          !SCR "{PINK}I HOPE YOU LIKE IT"
          !BYTE $08,$00    ; CURSOR UP, STRING TERMINATOR
          
SCROLLTEXT
          !SCR " WELCOME TO MY NEW DEMO. THIS SHOULD APPEAR VERY SMOOTH"
          !SCR "                            "  ; SPACING
          !BYTE $00        ; END OF TEXT MARKER